while True:
  print(eval(input(">>>")))
